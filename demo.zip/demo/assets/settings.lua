return {
    window = {
        title = "Super Awesome Game 9001",
        width = 720,
        height = 480
    },
    camera = {
        fov = 75
    },
    initialLevel = "LEVEL_1",
    tickRate = 1.0 / 60.0
}