return {
    position = engine.math.vec3.new(0, 900, 0),
    renderComponent = {
        mesh = 3313820357,
		shader = 2946951896
    }
}
