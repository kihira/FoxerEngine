return {
    name = "Rough Ground",
    position = engine.math.vec3.new(0.0),
    renderComponent = {
        mesh = 4214878900, -- MESH_GROUND
		shader = 2946951896
    }
}
