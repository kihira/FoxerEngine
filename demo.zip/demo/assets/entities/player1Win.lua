return {
    position = engine.math.vec3.new(0, 900, 0),
    renderComponent = {
        mesh = 1317505198,
		shader = 2946951896
    }
}
