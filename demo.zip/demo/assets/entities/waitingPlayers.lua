return {
    position = engine.math.vec3.new(0, 1000, 0),
    renderComponent = {
        mesh = 2992890141, -- MESH_WAITING_PLAYERS
		shader = 2946951896
    }
}
