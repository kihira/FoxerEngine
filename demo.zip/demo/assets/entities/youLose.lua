return {
    position = engine.math.vec3.new(0, 800, 0),
    renderComponent = {
        mesh = 1982698336,
		shader = 2946951896
    }
}
