return {
    position = engine.math.vec3.new(0, 800, 0),
    renderComponent = {
        mesh = 1730504262,
		shader = 2946951896
    }
}