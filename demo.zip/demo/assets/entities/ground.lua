return {
    name = "Ground",
    position = engine.math.vec3.new(0.0),
    renderComponent = {
        mesh = 2381128972, -- MESH_GROUND
		shader = 2946951896
    }
}
