return {
    file = "texture.png"
}