# Foxer Engine Editor
A basic implementation of an editor for the Foxer Engine

Its not fully featured but allows encoding Strings into StringIDs and basic entity editing