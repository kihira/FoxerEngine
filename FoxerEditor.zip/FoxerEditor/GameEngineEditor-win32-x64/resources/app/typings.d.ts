interface Window {
    $: JQuery;
    Bootstrap: any;
    dt: any;
    dtstyle: any;
}