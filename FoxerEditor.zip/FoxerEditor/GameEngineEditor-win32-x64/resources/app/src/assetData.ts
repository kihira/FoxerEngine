import {EntityData} from "./entityData";
import {LevelData} from "./levelData";

export interface AssetData {
    entities: Map<string, EntityData>;
    levels: Map<string, LevelData>;
    meshes: Map<string, string>;
    shaders: Map<string, string>;
}

export abstract class AssetDataBase {
    namespace: string;

    protected constructor(namespace: string) {
        this.namespace = namespace;
    }

    abstract loadFromString(data: string): void;
}