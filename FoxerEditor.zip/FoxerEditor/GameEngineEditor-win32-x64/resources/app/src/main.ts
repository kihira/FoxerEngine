import {app, BrowserWindow, dialog, ipcMain} from "electron";
import {existsSync, promises, writeFileSync} from "fs";
import {AssetData} from "./assetData";
import {EntityData, saveToString} from "./entityData";
import {LevelData} from "./levelData";

let mainWindow: BrowserWindow | null;
let gameDirectory: string;

function createWindow () {
    // Create the browser window.
    mainWindow = new BrowserWindow({width: 800, height: 600});

    // and load the index.html of the app.
    mainWindow.loadFile('index.html');

    // Open the DevTools.
    mainWindow.webContents.openDevTools();

    // Emitted when the window is closed.
    mainWindow.on('closed', function () {
        mainWindow = null;
    })
}

async function readFile(dir: string, file: string) : Promise<string> {
    return promises.readFile(dir + "/" + file, {encoding: "utf8", flag: "r"});
}

/**
 * Scans the selected asset directory and loads the data from it
 * @param assetDirectory
 */
async function loadAssetData(assetDirectory: string): Promise<AssetData> {
    let assetData: AssetData = {
        entities: new Map<string, EntityData>(),
        levels: new Map<string, LevelData>(),
        meshes: new Map<string, string>(),
        shaders: new Map<string, string>(),
    };

    // Load entities
    const entitiesDir = assetDirectory + "/entities";
    if (existsSync(entitiesDir)) {
        const files = await promises.readdir(entitiesDir);
        for (const file of files) {
            let entityData: EntityData = new EntityData(file);
            entityData.loadFromString(await readFile(entitiesDir, file));
            assetData.entities.set(file, entityData);
        }
    }

    // Load strings
    const stringsFile = assetDirectory + "/strings.txt";
    if (existsSync(stringsFile)) {
        const stringData = await readFile(assetDirectory, "strings.txt");
        let strings: {value: string, id: number}[] = [];
        stringData.split(/\n/).forEach((row) => {
            strings.push({
                value: row.split(" ")[0],
                id: parseInt(row.split(" ")[1])
            })
        });

        (mainWindow as BrowserWindow).webContents.send("load-strings", strings);
    }

    // Load levels
    const levelsDir = assetDirectory + "/levels";
    if (existsSync(levelsDir)) {
        const files = await promises.readdir(levelsDir);
        for (const file of files) {
            const fileData = await readFile(levelsDir, file);
            //assetData.levels.set(file, fileData);
        }
    }

    // Load meshes
    // const meshesDir = assetDirectory + "/meshes";
    // if (existsSync(meshesDir)) {
    //     const files = await promises.readdir(meshesDir);
    //     for (const file of files) {
    //         const fileData = await readFile(assetDirectory, file);
    //         assetData.meshes.set(file, fileData);
    //     }
    // }

    // Load shaders
    const shadersDir = assetDirectory + "/shaders";
    if (existsSync(shadersDir)) {
        const files = await promises.readdir(shadersDir);
        for (const file of files) {
            const fileData = await readFile(shadersDir, file);
            assetData.shaders.set(file, fileData);
        }
    }

    return assetData;
}

app.on('ready', function() {
    createWindow();
});

// Quit when all windows are closed.
app.on('window-all-closed', function () {
    // On OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
        app.quit()
    }
});

app.on('activate', function () {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (mainWindow === null) {
        createWindow()
    }
});

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.

// Listen for request to open file selection dialog
ipcMain.on("open-file-dialog", (event: any) => {
    dialog.showOpenDialog(<BrowserWindow>(mainWindow), {properties: ["openDirectory"]}, async (files) => {
        if (files.length == 1) {
            gameDirectory = files[0];
            await loadAssetData(gameDirectory);
            event.sender.send("selected-directory", gameDirectory);
            console.log("test")
        }
    })
});

ipcMain.on("save-level", (event: any, levelData: LevelData) => {
    console.log(levelData);
});

ipcMain.on("save-entity", (event: any, entityData: EntityData) => {
    console.log(entityData);
    console.log(saveToString(entityData));
});

ipcMain.on("save-strings", (event: any, strings: {value: string, id: number}[]) => {
    let output = "";
    strings.forEach((entry) => {
        output += entry.value + " " + entry.id + "\n";
    });

    output = output.substr(0, output.length - 2);

    writeFileSync(gameDirectory + "/strings.txt", output, {encoding: "utf8"});
});