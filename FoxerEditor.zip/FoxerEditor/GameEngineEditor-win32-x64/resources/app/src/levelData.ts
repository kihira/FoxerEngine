import {AssetDataBase} from "./assetData";

export class LevelData extends AssetDataBase {
    name: string;
    maxPlayers: number = 1;
    updateFn: string = "";


    constructor(namespace: string) {
        super(namespace);
        this.name = namespace;
    }

    loadFromString(data: string): void {
    }

    saveToString(): string {
        return "";
    }
}