window.$ = require("jquery");
window.Bootstrap = require("bootstrap");
window.dt = require("datatables.net")();
window.dtstyle = require( 'datatables.net-dt' )( window, window.$ );

const EntityData = require("./dist/entityData").EntityData;
const {ipcRenderer} = require("electron");

// Attach opening file dialog to selecting game directory
const selectGameDirBtn = document.getElementById("game-directory");
if (selectGameDirBtn != null) {
    selectGameDirBtn.addEventListener("click", () => {
        ipcRenderer.send("open-file-dialog");
    });
}

function onSelectColliderType() {
    switch (parseInt($("#entity-collider-shape-type").val() as string)) {
        case 0:
            $("#entity-collider-shape-circle").collapse("show");
            break;
        case 1:
            $("#entity-collider-shape-polygon").collapse("show");
            break;
        case 2:
            $("#entity-collider-shape-edge").collapse("show");
            break;
    }
}

function saveEntity() {
    let entityData = new EntityData($("#entity-name").val() as string);
    entityData.loadFromForm();
    ipcRenderer.send("save-entity", entityData);
}

function saveLevel() {
    // Build data structure from form data
    // let levelData: LevelData = new LevelData("TODO");
    // levelData.name = (document.getElementById("level-name") as HTMLInputElement).value;
    // levelData.maxPlayers = (document.getElementById("level-max-players") as HTMLInputElement).valueAsNumber;
    // levelData.updateFn = (document.getElementById("level-update") as HTMLInputElement).value;
    //
    // ipcRenderer.send("save-level", levelData);
}

/**
 * String ID stuff
 */

const stringsTable = $('#strings-table').DataTable({
    columns: [
        { data: "value" },
        { data: "id" }
    ]
});

/**
 * Called when a new string should be added to the string ID table
 */
function addNewString() {
    // Parse form
    let stringValue = (document.getElementById("string-value") as HTMLInputElement).value;
    let stringId = processString(stringValue);

    // Add row to table
    stringsTable.row.add({
        value: stringValue,
        id: stringId
    }).draw();

    // Reset form
    (document.getElementById("string-value") as HTMLInputElement).value = "";

    // Save file
    ipcRenderer.send("save-strings", stringsTable.data().toArray());
}

/**
 * Converts a string into a StringId
 * @param input
 */
function processString(input: string): number {
    let hash = 5381;
    const length = input.length;

    for (let c = 0; c < length; c++) {
        hash = (33 * hash) ^ input.charCodeAt(c);
    }

    return hash >>> 0;
}

ipcRenderer.on("load-strings", (event: any, strings: {value: string, id: number}[]) => {
    strings.forEach((string) => {
        stringsTable.row.add(string);
    });

    stringsTable.draw();
});

// Listen for when directory is selected
ipcRenderer.on("selected-directory", (event: any, path: string) => {
    const gameDirText = (document.getElementById("game-directory-text") as HTMLInputElement);
    if (gameDirText != null) {
        gameDirText.value = path;
    }
});