export function serialize(obj: {[key: string] : any}): string {
    let data = "";
    for (let property in obj) {
        if (obj.hasOwnProperty(property) && property != "namespace") {
            data += `${property} = `;
            if (typeof obj[property] == "object") {
                data += `{`;
                // Parse arrays
                if (Array.isArray(obj[property])) {
                    (obj[property] as Array<any>).forEach((value, index) => {
                        data += value;
                        if (index < (obj[property] as Array<any>).length -1) {
                            data += ",";
                        }
                    });
                } else { // Parse objects recursively
                    data += `\n${serialize(obj[property])}`;
                }
                data += `}`;
            } else if (property.endsWith("Fn")) { // Parse functions
                data += `function(self)\n${obj[property]}\n end`;
            } else if (typeof obj[property] == "string") {
                data += `"${obj[property]}"`;
            } else { //
                data += `${obj[property]}`;
            }
            data += ",\n";
        }
    }
    return data;
}