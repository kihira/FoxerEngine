import {AssetDataBase} from "./assetData";
import {parse} from "luaparse";
import {serialize} from "./lua";

interface Collider {
    active: boolean;
    angularDamping: number;
    bullet: boolean;
    linearDamping: number;
    gravityScale: number;
    type: number;
    fixedRotation: boolean;
    // Fixture data
    density: number;
    friction: number;
    restitution: number;
    shape: number;
    // Circle
    radius?: number;
    // Polygon
    halfWidth: number;
    halfHeight: number;
}

export class EntityData extends AssetDataBase {
    name: string;
    position: number[] = [0, 0, 0];
    rotation: number[] = [0, 0, 0];
    updateFn: string = "";
    collider!: Collider;

    constructor(namespace: string) {
        super(namespace);
        this.name = namespace;
    }

    loadFromForm() {
        this.name = $("#entity-name").val() as string;
        this.position = [
            parseInt($("#entity-position-x").val() as string),
            parseInt($("#entity-position-y").val() as string),
            parseInt($("#entity-position-z").val() as string),
        ];
        this.rotation = [
            parseInt($("#entity-rotation-x").val() as string),
            parseInt($("#entity-rotation-y").val() as string),
            parseInt($("#entity-rotation-z").val() as string),
        ];
        this.updateFn = $("#entity-update").val() as string;
        this.collider = {
            active: $("#entity-collider-active").is(":checked"),
            angularDamping: parseInt($("#entity-collider-angularDamping").val() as string),
            bullet: $("#entity-collider-bullet").is(":checked"),
            linearDamping: parseInt($("#entity-collider-linearDamping").val() as string),
            gravityScale: parseInt($("#entity-collider-gravityScale").val() as string),
            type: parseInt($("#entity-collider-type").val() as string),
            fixedRotation: $("#entity-collider-fixedRotation").is(":checked"),
            density: parseInt($("#entity-collider-density").val() as string),
            friction: parseInt($("#entity-collider-friction").val() as string),
            restitution: parseInt($("#entity-collider-restitution").val() as string),
            shape: parseInt($("#entity-collider-shape-type").val() as string),
            radius: parseInt($("#entity-collider-shape-radius").val() as string),
            halfWidth: parseInt($("#entity-collider-shape-halfWidth").val() as string),
            halfHeight: parseInt($("#entity-collider-shape-halfHeight").val() as string)
        }
    }

    loadFromString(data: string) {
        const parsedData = parse(data);
        // Find namespace
        const namespace = /([a-zA-Z])=/;

    }
}

export function saveToString(entity: EntityData) {
    let data = `${entity.namespace} = {\n`;
    data += serialize(entity);
    data += "}";
    return data;
}